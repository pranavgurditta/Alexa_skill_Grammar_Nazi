from random_word import RandomWords
from PyDictionary import PyDictionary
dictionary=PyDictionary()
r=RandomWords()
e=r.get_random_word()
print(e)
print (dictionary.meaning(e))
