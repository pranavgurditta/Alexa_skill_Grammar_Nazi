import requests
import pylanguagetool
import json
import unidecode
import ast

def f(q):
        api_url="https://api.textgears.com/check.php?text="+q+"!&key=ANGS8LoUPRrCpV8n"

        response = requests.get(api_url)
        if response.status_code == 200:
            return (json.loads(json.dumps(response.content.decode('utf-8'))))
        else:
            return None
        
def fg():
        
        k=f("My name is pranav")
        s = k.replace("{" ,"")
        print(s)
        finalstring = s.replace("}" , "")

#Splitting the string based on , we get key value pairs
        list = finalstring.split(",")

        dict ={}
        for i in list:
    #Get Key Value pairs separately to store in dictionary
                keyvalue = i.split(":")
                m= keyvalue[0].strip('\'')
                m = m.replace("\"", "")
                dict[m] = keyvalue[1].strip('"\'')

        print (dicti['bad'])
        
        
fg()


    
    
    
    
    
