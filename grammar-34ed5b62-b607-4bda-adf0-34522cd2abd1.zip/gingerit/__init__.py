# -*- coding: utf-8 -*-

__author__ = 'Tim Kleinschmidt'
__email__ = 'tim.kleinschmidt@gmail.com'
__version__ = '0.6.0'
