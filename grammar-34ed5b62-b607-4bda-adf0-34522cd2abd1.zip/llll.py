from gingerit.gingerit import GingerIt

text = 'I am an boy.'

parser = GingerIt()
print(parser.parse(text))
s=''.join(map(str, parser.parse(text)['corrections']))
print (s)
if(s==''):
    speech_output="Your sentence is correct"
else:
    speech_output="The correct sentence is "+parser.parse(text)['result']
        
    
print (speech_output)
