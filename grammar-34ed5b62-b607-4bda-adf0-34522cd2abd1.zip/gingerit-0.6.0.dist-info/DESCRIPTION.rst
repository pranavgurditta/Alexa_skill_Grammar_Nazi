Correcting spelling and grammar mistakes based on the context of complete sentences. Wrapper around the gingersoftware.com API


